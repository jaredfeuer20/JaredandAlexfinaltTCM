class Paddles {
    
    display() {
    stroke(0);
    fill(255);
    rect(0, mouseY, 20, 100);
    }

}