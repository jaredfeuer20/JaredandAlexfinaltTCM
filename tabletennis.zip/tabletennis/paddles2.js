class Paddles2 {
    
    display() {
    stroke(0);
    fill(255);
    rect(780, 350, 20, 100);
    }

}